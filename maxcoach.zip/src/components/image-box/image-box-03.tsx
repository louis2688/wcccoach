import { forwardRef } from "react";
import Anchor from "@ui/anchor";
import { ImageType } from "@utils/types";

export type ImageBoxProps = {
    image: ImageType;
    title: string;
    description: string;
    path: string;
    pathText: string;
};

const ImageBox = forwardRef<HTMLDivElement, ImageBoxProps>(
    ({ image, title, description, path, pathText }, ref) => {
        return (
            <div
                ref={ref}
                className="image-box tw-relative tw-group tw-text-center"
            >
                {image?.src && (
                    <img
                        src={image.src}
                        alt={image?.alt || title}
                        className="tw-mb-6 tw-mx-auto"
                    />
                )}
                <h3 className="tw-leading-normal tw-text-xl tw-m-0">{title}</h3>
                <p className="tw-leading-relaxed tw-mt-2.5 tw-mb-[34px]">
                    {description}
                </p>
                <span className="tw-text-md tw-font-bold tw-leading-none tw-flex tw-items-center tw-justify-center tw-px-5 tw-min-h-[40px] tw-bg-transparent tw-rounded tw-text-secondary-light tw-transition group-hover:tw-bg-light-100 group-hover:tw-text-primary">
                    {pathText}{" "}
                    <i className="fa fa-arrow-right tw-ml-3.5 tw-text-[16px]" />
                </span>
                <Anchor className="link-overlay" path={path}>
                    {title}
                </Anchor>
            </div>
        );
    }
);

ImageBox.displayName = "ImageBox";

export default ImageBox;
