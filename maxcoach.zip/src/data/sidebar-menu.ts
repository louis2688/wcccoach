export default [
    { id: 1, path: "/about-me", label: "About Me" },
    { id: 2, path: "/contact-me", label: "Contact Me" },
    { id: 3, path: "/purchase-guide", label: "Purchase Guide" },
    { id: 4, path: "/privacy-policy", label: "Privacy Policy" },
    { id: 5, path: "/terms-of-service", label: "Terms of Service" },
];
