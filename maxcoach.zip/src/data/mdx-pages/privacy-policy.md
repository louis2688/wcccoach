![alt text](/images/purchase-guide/privacy-policy.jpg)

This Privacy Policy is applicabled for any one involves with the registering and course engagement at WCCCoach Online Course Educational center.

### Availability of Website

In order to buy any course or become a member of our center, customers/ learners must first register with a personal account providing the following information:

1.  Member recognizes that the traffic of data through the Internet may cause delays
    during the download of information from the website and accordingly, it shall not hold the Company liable for delays that are ordinary in the course of Internet use.
2.  Member further acknowledges and accepts that the website will not be available on a continual twenty-four hour basis due to such delays, or delays caused by the Company’s upgrading, modification, or standard maintenance of the website.

### Intellectual Property Rights

1.  The online course is owned by the Company and is protected by American and international copyright, trademark, patent, trade secret and other intellectual property or proprietary rights laws.

2.  No right, title or interest in or to the online course or any portion thereof, is transferred to any Member, and all rights not expressly granted herein, are reserved by the Company.

3.  The Company name, the Company logo, and all related names, logos, product and service names, designs
    and slogans, are trademarks of the Company. Member may not use such marks
    without the prior written permission of the Company.

### Company Obligations

The Company will use commercially reasonable efforts to enable the online course to be accessible, except for scheduled maintenance and required repairs, and except for any interruption due to causes beyond the reasonable control of, or not reasonably foreseeable by the Company.

### Governing Law and Venue

1.  These Terms of Service are construed and governed by the laws of the United States of America.
2.  If any of the provisions, either in whole or in part, of the contract is or becomes invalid or unenforceable, this shall not serve to invalidate the remaining provisions thereof.

**Effective Date: 01/01/2020**
