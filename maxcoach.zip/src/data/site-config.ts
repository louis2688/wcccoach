export default {
    name: "MaxCoach",
    titleTemplate: "Online Learning React Education Template",
    description: "Online Learning and Education React NextJS Template",
};
